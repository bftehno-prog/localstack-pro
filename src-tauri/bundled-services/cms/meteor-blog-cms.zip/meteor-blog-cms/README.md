# Meteor Blog CMS

Готовый стартовый проект блоговой CMS на **Meteor 3.4.1 + Blaze + MongoDB**.

## Что внутри

- публичный блог;
- админка;
- вход администратора;
- роли `admin` и `editor`;
- посты: создание, редактирование, публикация, черновики, удаление;
- категории;
- теги;
- cover URL для изображения поста;
- комментарии с модерацией;
- настройки сайта;
- демо-контент при первом запуске;
- адаптивная тёмная тема без React/Vue/Bootstrap/Tailwind.

## Структура

```txt
meteor-blog-cms/
├─ .meteor/
│  ├─ packages
│  └─ release
├─ client/
│  ├─ main.js
│  └─ main.css
├─ server/
│  ├─ main.js
│  ├─ publications.js
│  └─ seed.js
├─ imports/
│  ├─ api/
│  │  ├─ collections.js
│  │  ├─ methods.js
│  │  └─ utils.js
│  └─ ui/
│     ├─ app.html
│     ├─ app.js
│     └─ state.js
├─ public/
├─ settings.json
├─ settings.example.json
└─ package.json
```

## Запуск локально

Установи Meteor, затем:

```bash
cd meteor-blog-cms
npm install
meteor npm install
meteor run --settings settings.json
```

Открой:

```txt
http://localhost:3000
```

Админка:

```txt
http://localhost:3000/#/login
```

Данные по умолчанию из `settings.json`:

```txt
Email: admin@example.com
Password: ChangeMe123!
```

## Как поменять администратора

Открой `settings.json`:

```json
{
  "private": {
    "admin": {
      "email": "admin@example.com",
      "password": "ChangeMe123!",
      "name": "Admin"
    }
  }
}
```

При первом запуске CMS создаст администратора автоматически. Если база уже создана, поменяй данные вручную в MongoDB или сделай сброс локальной базы:

```bash
meteor reset
meteor run --settings settings.json
```

## Основные маршруты

```txt
#/                    публичный блог
#/post/first-post     страница поста
#/login               вход
#/admin               дашборд
#/admin/posts         список постов
#/admin/new           новый пост
#/admin/edit/:id      редактирование
#/admin/categories    категории
#/admin/comments      комментарии
#/admin/settings      настройки сайта
```

## Важно для продакшена

Перед публикацией замени пароль администратора, настрой постоянную MongoDB, `ROOT_URL`, `MONGO_URL` и деплой на сервер/облако, которое поддерживает Meteor/Node.js. На обычном PHP shared-hosting Meteor напрямую не запускается, нужен Node.js runtime или VPS.
