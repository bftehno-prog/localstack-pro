import { Meteor } from 'meteor/meteor';
import { Template } from 'meteor/templating';
import { Posts, Categories, Settings } from '/imports/api/collections';
import { Route, IsAdmin, Flash } from '/imports/ui/state';
import '/imports/ui/app.html';
import '/imports/ui/app.js';
import './main.css';

Meteor.startup(() => {
  Meteor.subscribe('settings.public');
  Meteor.subscribe('categories.public');
});

Template.registerHelper('equals', (a, b) => a === b);
Template.registerHelper('flash', () => Flash.get());
Template.registerHelper('isAdmin', () => IsAdmin.get());
Template.registerHelper('site', (field) => {
  const settings = Settings.findOne('main') || {};
  const defaults = {
    siteName: Meteor.settings?.public?.siteName || 'Meteor Blog CMS',
    siteDescription: 'Блоговая CMS на Meteor JS',
    footerText: 'Powered by Meteor Blog CMS',
    heroTitle: 'Блоговая CMS на Meteor',
    heroText: 'Пиши, публикуй и управляй блогом в реальном времени.'
  };
  return settings[field] || defaults[field] || '';
});
Template.registerHelper('routeName', () => Route.get().name);
Template.registerHelper('formatDate', (date) => {
  if (!date) return '—';
  return new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: 'short', year: 'numeric' }).format(date);
});
Template.registerHelper('categoryTitle', (categoryId) => Categories.findOne(categoryId)?.title || 'Без категории');
Template.registerHelper('publishedCount', () => Posts.find({ status: 'published' }).count());
