import { Meteor } from 'meteor/meteor';
import { Accounts } from 'meteor/accounts-base';
import { Roles } from 'meteor/roles';
import { Posts, Categories, Settings } from '/imports/api/collections';

const getAdminSettings = () => {
  const cfg = Meteor.settings?.private?.admin || {};
  return {
    email: process.env.ADMIN_EMAIL || cfg.email || 'admin@example.com',
    password: process.env.ADMIN_PASSWORD || cfg.password || 'ChangeMe123!',
    name: process.env.ADMIN_NAME || cfg.name || 'Admin'
  };
};

Meteor.startup(async () => {
  await Roles.createRoleAsync('admin', { unlessExists: true });
  await Roles.createRoleAsync('editor', { unlessExists: true });

  const admin = getAdminSettings();
  let adminUser = await Accounts.findUserByEmail(admin.email);

  if (!adminUser) {
    const userId = await Accounts.createUserAsync({
      email: admin.email,
      password: admin.password,
      profile: { name: admin.name }
    });
    await Roles.addUsersToRolesAsync(userId, ['admin']);
    adminUser = await Meteor.users.findOneAsync(userId);
    console.log(`[seed] Admin created: ${admin.email} / ${admin.password}`);
  } else {
    await Roles.addUsersToRolesAsync(adminUser._id, ['admin'], { ifExists: true });
  }

  const settings = await Settings.findOneAsync('main');
  if (!settings) {
    await Settings.insertAsync({
      _id: 'main',
      siteName: Meteor.settings?.public?.siteName || 'Meteor Blog CMS',
      siteDescription: 'Лёгкая блоговая CMS на Meteor JS с админкой, категориями и комментариями.',
      heroTitle: 'Блоговая CMS на Meteor',
      heroText: 'Пиши статьи, управляй категориями, публикуй материалы и модерируй комментарии в реальном времени.',
      footerText: 'Powered by Meteor Blog CMS',
      createdAt: new Date(),
      updatedAt: new Date()
    });
  }

  if (await Categories.find().countAsync() === 0) {
    await Categories.insertAsync({
      title: 'Новости',
      slug: 'news',
      description: 'Обновления проекта и короткие заметки.',
      createdAt: new Date(),
      updatedAt: new Date()
    });
    await Categories.insertAsync({
      title: 'Гайды',
      slug: 'guides',
      description: 'Полезные инструкции и разборы.',
      createdAt: new Date(),
      updatedAt: new Date()
    });
  }

  if (await Posts.find().countAsync() === 0) {
    const guideCategory = await Categories.findOneAsync({ slug: 'guides' });
    await Posts.insertAsync({
      title: 'Первый пост в CMS',
      slug: 'first-post',
      excerpt: 'Это демо-запись, которую можно удалить или отредактировать в админке.',
      content: 'Добро пожаловать в Meteor Blog CMS.\n\nЗдесь уже есть публикации, категории, комментарии и базовые настройки сайта. Перейди в админку, войди под администратором и создай свой первый материал.',
      coverUrl: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=1600&q=80',
      categoryId: guideCategory?._id || null,
      tags: ['Meteor', 'CMS', 'Blog'],
      status: 'published',
      featured: true,
      authorId: adminUser?._id,
      views: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
      publishedAt: new Date()
    });
  }
});
