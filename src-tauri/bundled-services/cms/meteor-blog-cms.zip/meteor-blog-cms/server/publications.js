import { Meteor } from 'meteor/meteor';
import { Roles } from 'meteor/roles';
import { Posts, Categories, Comments, Settings, publicPostFields } from '/imports/api/collections';

Meteor.publish('settings.public', function () {
  return Settings.find({ _id: 'main' }, {
    fields: {
      siteName: 1,
      siteDescription: 1,
      footerText: 1,
      heroTitle: 1,
      heroText: 1
    }
  });
});

Meteor.publish('categories.public', function () {
  return Categories.find({}, { sort: { title: 1 } });
});

Meteor.publish('posts.public', function () {
  return Posts.find({ status: 'published' }, {
    fields: publicPostFields,
    sort: { featured: -1, publishedAt: -1, createdAt: -1 },
    limit: 100
  });
});

Meteor.publish('comments.public', function (postId) {
  if (!postId || typeof postId !== 'string') {
    this.ready();
    return;
  }

  return Comments.find({ postId, approved: true }, {
    sort: { createdAt: -1 },
    limit: 50
  });
});

Meteor.publish('posts.admin', async function () {
  if (!this.userId || !await Roles.userIsInRoleAsync(this.userId, 'admin')) {
    this.ready();
    return;
  }

  return Posts.find({}, { sort: { updatedAt: -1, createdAt: -1 } });
});

Meteor.publish('comments.admin', async function () {
  if (!this.userId || !await Roles.userIsInRoleAsync(this.userId, 'admin')) {
    this.ready();
    return;
  }

  return Comments.find({}, { sort: { createdAt: -1 }, limit: 300 });
});

Meteor.publish('users.adminList', async function () {
  if (!this.userId || !await Roles.userIsInRoleAsync(this.userId, 'admin')) {
    this.ready();
    return;
  }

  return Meteor.users.find({}, {
    fields: {
      username: 1,
      emails: 1,
      profile: 1,
      createdAt: 1
    },
    limit: 100
  });
});
