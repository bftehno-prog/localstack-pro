import '/imports/api/methods';
import './publications';
import './seed';
