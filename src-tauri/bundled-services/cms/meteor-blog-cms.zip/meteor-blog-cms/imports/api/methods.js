import { Meteor } from 'meteor/meteor';
import { check, Match } from 'meteor/check';
import { Roles } from 'meteor/roles';
import { Posts, Categories, Comments, Settings, POST_STATUSES } from './collections';
import { normalizeTags, slugify, trimText } from './utils';

const requireAdmin = async (userId) => {
  if (!userId) {
    throw new Meteor.Error('not-authorized', 'Нужно войти в админку.');
  }

  const isAdmin = await Roles.userIsInRoleAsync(userId, 'admin');
  if (!isAdmin) {
    throw new Meteor.Error('not-authorized', 'Недостаточно прав.');
  }
};

const makeUniqueSlug = async (baseSlug, currentId = null) => {
  const base = slugify(baseSlug);
  let next = base;
  let index = 2;

  while (await Posts.findOneAsync({ slug: next, ...(currentId ? { _id: { $ne: currentId } } : {}) })) {
    next = `${base}-${index}`;
    index += 1;
  }

  return next;
};

const postShape = {
  _id: Match.Optional(String),
  title: String,
  slug: Match.Optional(String),
  excerpt: Match.Optional(String),
  content: Match.Optional(String),
  coverUrl: Match.Optional(String),
  categoryId: Match.Optional(Match.Maybe(String)),
  tags: Match.Optional(Match.OneOf(String, [String])),
  status: Match.Optional(String),
  featured: Match.Optional(Boolean)
};

Meteor.methods({
  async 'users.isAdmin'() {
    return Boolean(this.userId && await Roles.userIsInRoleAsync(this.userId, 'admin'));
  },

  async 'posts.upsert'(doc) {
    check(doc, postShape);
    await requireAdmin(this.userId);

    const title = trimText(doc.title, 180);
    if (title.length < 3) {
      throw new Meteor.Error('validation-error', 'Название должно быть не короче 3 символов.');
    }

    const now = new Date();
    const status = POST_STATUSES.includes(doc.status) ? doc.status : 'draft';
    const slug = await makeUniqueSlug(doc.slug || title, doc._id);

    const payload = {
      title,
      slug,
      excerpt: trimText(doc.excerpt, 420),
      content: trimText(doc.content, 50000),
      coverUrl: trimText(doc.coverUrl, 1000),
      categoryId: doc.categoryId || null,
      tags: normalizeTags(doc.tags),
      status,
      featured: Boolean(doc.featured),
      updatedAt: now
    };

    if (status === 'published') {
      payload.publishedAt = now;
    }

    if (doc._id) {
      await Posts.updateAsync(doc._id, { $set: payload });
      return doc._id;
    }

    return Posts.insertAsync({
      ...payload,
      authorId: this.userId,
      views: 0,
      createdAt: now,
      publishedAt: status === 'published' ? now : null
    });
  },

  async 'posts.remove'(postId) {
    check(postId, String);
    await requireAdmin(this.userId);
    await Comments.removeAsync({ postId });
    return Posts.removeAsync(postId);
  },

  async 'posts.setStatus'(postId, status) {
    check(postId, String);
    check(status, String);
    await requireAdmin(this.userId);

    if (!POST_STATUSES.includes(status)) {
      throw new Meteor.Error('validation-error', 'Некорректный статус.');
    }

    const patch = { status, updatedAt: new Date() };
    if (status === 'published') {
      patch.publishedAt = new Date();
    }

    return Posts.updateAsync(postId, { $set: patch });
  },

  async 'posts.incrementViews'(slug) {
    check(slug, String);
    const post = await Posts.findOneAsync({ slug, status: 'published' }, { fields: { _id: 1 } });
    if (!post) return false;
    await Posts.updateAsync(post._id, { $inc: { views: 1 } });
    return true;
  },

  async 'categories.upsert'(doc) {
    check(doc, {
      _id: Match.Optional(String),
      title: String,
      slug: Match.Optional(String),
      description: Match.Optional(String)
    });
    await requireAdmin(this.userId);

    const title = trimText(doc.title, 120);
    if (title.length < 2) {
      throw new Meteor.Error('validation-error', 'Название категории слишком короткое.');
    }

    const baseSlug = slugify(doc.slug || title);
    let slug = baseSlug;
    let index = 2;
    while (await Categories.findOneAsync({ slug, ...(doc._id ? { _id: { $ne: doc._id } } : {}) })) {
      slug = `${baseSlug}-${index}`;
      index += 1;
    }

    const payload = {
      title,
      slug,
      description: trimText(doc.description, 280),
      updatedAt: new Date()
    };

    if (doc._id) {
      await Categories.updateAsync(doc._id, { $set: payload });
      return doc._id;
    }

    return Categories.insertAsync({ ...payload, createdAt: new Date() });
  },

  async 'categories.remove'(categoryId) {
    check(categoryId, String);
    await requireAdmin(this.userId);
    await Posts.updateAsync({ categoryId }, { $set: { categoryId: null } }, { multi: true });
    return Categories.removeAsync(categoryId);
  },

  async 'comments.create'(doc) {
    check(doc, {
      postId: String,
      authorName: String,
      body: String
    });

    const post = await Posts.findOneAsync({ _id: doc.postId, status: 'published' }, { fields: { _id: 1 } });
    if (!post) {
      throw new Meteor.Error('not-found', 'Пост не найден.');
    }

    const authorName = trimText(doc.authorName, 80);
    const body = trimText(doc.body, 1200);
    if (authorName.length < 2 || body.length < 3) {
      throw new Meteor.Error('validation-error', 'Заполни имя и комментарий.');
    }

    return Comments.insertAsync({
      postId: doc.postId,
      authorName,
      body,
      approved: false,
      createdAt: new Date()
    });
  },

  async 'comments.setApproved'(commentId, approved) {
    check(commentId, String);
    check(approved, Boolean);
    await requireAdmin(this.userId);
    return Comments.updateAsync(commentId, { $set: { approved, updatedAt: new Date() } });
  },

  async 'comments.remove'(commentId) {
    check(commentId, String);
    await requireAdmin(this.userId);
    return Comments.removeAsync(commentId);
  },

  async 'settings.update'(doc) {
    check(doc, {
      siteName: String,
      siteDescription: Match.Optional(String),
      footerText: Match.Optional(String),
      heroTitle: Match.Optional(String),
      heroText: Match.Optional(String)
    });
    await requireAdmin(this.userId);

    return Settings.upsertAsync('main', {
      $set: {
        siteName: trimText(doc.siteName, 120),
        siteDescription: trimText(doc.siteDescription, 260),
        footerText: trimText(doc.footerText, 260),
        heroTitle: trimText(doc.heroTitle, 160),
        heroText: trimText(doc.heroText, 320),
        updatedAt: new Date()
      },
      $setOnInsert: { createdAt: new Date() }
    });
  }
});
