import { Mongo } from 'meteor/mongo';

export const Posts = new Mongo.Collection('posts');
export const Categories = new Mongo.Collection('categories');
export const Comments = new Mongo.Collection('comments');
export const Settings = new Mongo.Collection('settings');

export const POST_STATUSES = ['draft', 'published'];

export const publicPostFields = {
  title: 1,
  slug: 1,
  excerpt: 1,
  content: 1,
  coverUrl: 1,
  categoryId: 1,
  tags: 1,
  status: 1,
  featured: 1,
  authorId: 1,
  createdAt: 1,
  updatedAt: 1,
  publishedAt: 1,
  views: 1
};
