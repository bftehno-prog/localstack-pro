import { Meteor } from 'meteor/meteor';
import { ReactiveVar } from 'meteor/reactive-var';
import { Tracker } from 'meteor/tracker';

export const Route = new ReactiveVar(parseRoute());
export const IsAdmin = new ReactiveVar(false);
export const Flash = new ReactiveVar(null);

function parseRoute() {
  const raw = window.location.hash.replace(/^#\/?/, '').replace(/\?.*$/, '');
  const parts = raw.split('/').filter(Boolean);

  if (parts.length === 0) return { name: 'home', params: {} };
  if (parts[0] === 'post' && parts[1]) return { name: 'post', params: { slug: parts[1] } };
  if (parts[0] === 'login') return { name: 'login', params: {} };
  if (parts[0] === 'admin' && !parts[1]) return { name: 'adminDashboard', params: {} };
  if (parts[0] === 'admin' && parts[1] === 'posts') return { name: 'adminPosts', params: {} };
  if (parts[0] === 'admin' && parts[1] === 'new') return { name: 'postEditor', params: { id: null } };
  if (parts[0] === 'admin' && parts[1] === 'edit' && parts[2]) return { name: 'postEditor', params: { id: parts[2] } };
  if (parts[0] === 'admin' && parts[1] === 'categories') return { name: 'adminCategories', params: {} };
  if (parts[0] === 'admin' && parts[1] === 'comments') return { name: 'adminComments', params: {} };
  if (parts[0] === 'admin' && parts[1] === 'settings') return { name: 'adminSettings', params: {} };

  return { name: 'notFound', params: {} };
}

export const go = (path) => {
  window.location.hash = path;
};

export const flash = (message, type = 'ok') => {
  Flash.set({ message, type });
  window.setTimeout(() => Flash.set(null), 3200);
};

if (Meteor.isClient) {
  window.addEventListener('hashchange', () => Route.set(parseRoute()));

  Tracker.autorun(() => {
    if (!Meteor.userId()) {
      IsAdmin.set(false);
      return;
    }

    Meteor.call('users.isAdmin', (error, result) => {
      IsAdmin.set(!error && Boolean(result));
    });
  });
}
