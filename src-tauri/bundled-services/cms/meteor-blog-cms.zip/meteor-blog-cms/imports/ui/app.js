import { Meteor } from 'meteor/meteor';
import { Template } from 'meteor/templating';
import { ReactiveVar } from 'meteor/reactive-var';
import { Posts, Categories, Comments, Settings } from '/imports/api/collections';
import { Route, flash, go } from './state';

const routeTemplates = {
  home: 'homePage',
  post: 'postPage',
  login: 'loginPage',
  adminDashboard: 'adminDashboard',
  adminPosts: 'adminPosts',
  postEditor: 'postEditor',
  adminCategories: 'adminCategories',
  adminComments: 'adminComments',
  adminSettings: 'adminSettings',
  notFound: 'notFound'
};

const escapeHtml = (value) => String(value || '')
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#039;');

const textToHtml = (value) => escapeHtml(value)
  .split(/\n{2,}/)
  .map((block) => `<p>${block.replace(/\n/g, '<br>')}</p>`)
  .join('');

const currentPost = () => {
  const id = Route.get().params.id;
  if (!id) return { status: 'draft', tags: [] };
  return Posts.findOne(id) || { status: 'draft', tags: [] };
};

const call = (method, ...args) => new Promise((resolve, reject) => {
  Meteor.call(method, ...args, (error, result) => {
    if (error) reject(error);
    else resolve(result);
  });
});

Template.app.helpers({
  routeTemplate() {
    return routeTemplates[Route.get().name] || 'notFound';
  }
});

Template.app.events({
  'click .js-logout'() {
    Meteor.logout(() => {
      flash('Ты вышел из CMS.');
      go('/');
    });
  }
});

Template.homePage.onCreated(function () {
  this.search = new ReactiveVar('');
  this.categoryId = new ReactiveVar('');
  this.subscribe('posts.public');
});

Template.homePage.helpers({
  categories() {
    return Categories.find({}, { sort: { title: 1 } });
  },
  posts() {
    const instance = Template.instance();
    const query = instance.search.get().toLowerCase();
    const categoryId = instance.categoryId.get();

    return Posts.find({ status: 'published' }, {
      sort: { featured: -1, publishedAt: -1, createdAt: -1 }
    }).fetch().filter((post) => {
      const byCategory = !categoryId || post.categoryId === categoryId;
      const haystack = `${post.title || ''} ${post.excerpt || ''} ${(post.tags || []).join(' ')}`.toLowerCase();
      const bySearch = !query || haystack.includes(query);
      return byCategory && bySearch;
    });
  }
});

Template.homePage.events({
  'input .js-search'(event, instance) {
    instance.search.set(event.currentTarget.value);
  },
  'change .js-category-filter'(event, instance) {
    instance.categoryId.set(event.currentTarget.value);
  }
});

Template.postPage.onCreated(function () {
  this.viewed = {};
  this.autorun(() => {
    const slug = Route.get().params.slug;
    this.subscribe('posts.public');
    const post = Posts.findOne({ slug, status: 'published' });
    if (post) {
      this.subscribe('comments.public', post._id);
      if (!this.viewed[slug]) {
        this.viewed[slug] = true;
        Meteor.call('posts.incrementViews', slug);
      }
    }
  });
});

Template.postPage.helpers({
  post() {
    return Posts.findOne({ slug: Route.get().params.slug, status: 'published' });
  },
  contentHtml() {
    return textToHtml(this.content);
  },
  approvedComments() {
    return Comments.find({ postId: this._id, approved: true }, { sort: { createdAt: -1 } });
  }
});

Template.postPage.events({
  async 'submit .js-comment-form'(event) {
    event.preventDefault();
    const form = event.currentTarget;

    try {
      await call('comments.create', {
        postId: form.postId.value,
        authorName: form.authorName.value,
        body: form.body.value
      });
      form.reset();
      flash('Комментарий отправлен на модерацию.');
    } catch (error) {
      flash(error.reason || error.message, 'error');
    }
  }
});

Template.loginPage.events({
  'submit .js-login'(event) {
    event.preventDefault();
    const form = event.currentTarget;

    Meteor.loginWithPassword(form.email.value, form.password.value, (error) => {
      if (error) {
        flash(error.reason || 'Не удалось войти.', 'error');
        return;
      }
      flash('Вход выполнен.');
      go('/admin');
    });
  }
});

const subscribeAdmin = (instance, ...names) => {
  instance.autorun(() => {
    if (!Meteor.userId()) return;
    names.forEach((name) => instance.subscribe(name));
  });
};

Template.adminDashboard.onCreated(function () {
  subscribeAdmin(this, 'posts.admin', 'comments.admin');
});

Template.adminDashboard.helpers({
  totalPosts() {
    return Posts.find().count();
  },
  publishedPosts() {
    return Posts.find({ status: 'published' }).count();
  },
  draftPosts() {
    return Posts.find({ status: 'draft' }).count();
  },
  pendingComments() {
    return Comments.find({ approved: false }).count();
  }
});

Template.adminPosts.onCreated(function () {
  subscribeAdmin(this, 'posts.admin');
});

Template.adminPosts.helpers({
  adminPostsList() {
    return Posts.find({}, { sort: { updatedAt: -1, createdAt: -1 } });
  }
});

Template.adminPosts.events({
  async 'click .js-status'(event) {
    try {
      await call('posts.setStatus', this._id, event.currentTarget.dataset.status);
      flash('Статус обновлён.');
    } catch (error) {
      flash(error.reason || error.message, 'error');
    }
  },
  async 'click .js-remove-post'() {
    if (!window.confirm('Удалить пост вместе с комментариями?')) return;
    try {
      await call('posts.remove', this._id);
      flash('Пост удалён.');
    } catch (error) {
      flash(error.reason || error.message, 'error');
    }
  }
});

Template.postEditor.onCreated(function () {
  subscribeAdmin(this, 'posts.admin');
});

Template.postEditor.helpers({
  editorTitle() {
    return Route.get().params.id ? 'Редактирование поста' : 'Новый пост';
  },
  currentPost,
  categories() {
    return Categories.find({}, { sort: { title: 1 } });
  },
  tagsValue() {
    return (currentPost().tags || []).join(', ');
  },
  selectedCategory(categoryId) {
    return currentPost().categoryId === categoryId ? { selected: true } : {};
  },
  selectedStatus(status) {
    return (currentPost().status || 'draft') === status ? { selected: true } : {};
  },
  featuredChecked() {
    return currentPost().featured ? { checked: true } : {};
  }
});

Template.postEditor.events({
  async 'submit .js-post-form'(event) {
    event.preventDefault();
    const form = event.currentTarget;

    try {
      const id = await call('posts.upsert', {
        _id: form._id.value || undefined,
        title: form.title.value,
        slug: form.slug.value,
        excerpt: form.excerpt.value,
        content: form.content.value,
        coverUrl: form.coverUrl.value,
        categoryId: form.categoryId.value || null,
        tags: form.tags.value,
        status: form.status.value,
        featured: form.featured.checked
      });
      flash('Пост сохранён.');
      go(`/admin/edit/${id}`);
    } catch (error) {
      flash(error.reason || error.message, 'error');
    }
  }
});

Template.adminCategories.onCreated(function () {
  subscribeAdmin(this, 'posts.admin');
});

Template.adminCategories.helpers({
  categories() {
    return Categories.find({}, { sort: { title: 1 } });
  }
});

Template.adminCategories.events({
  async 'submit .js-category-form'(event) {
    event.preventDefault();
    const form = event.currentTarget;

    try {
      await call('categories.upsert', {
        _id: form._id.value || undefined,
        title: form.title.value,
        slug: form.slug.value,
        description: form.description.value
      });
      form.reset();
      flash('Категория сохранена.');
    } catch (error) {
      flash(error.reason || error.message, 'error');
    }
  },
  'click .js-edit-category'(event, template) {
    const form = template.find('.js-category-form');
    form._id.value = this._id;
    form.title.value = this.title || '';
    form.slug.value = this.slug || '';
    form.description.value = this.description || '';
    form.title.focus();
  },
  async 'click .js-remove-category'() {
    if (!window.confirm('Удалить категорию? Посты останутся без категории.')) return;
    try {
      await call('categories.remove', this._id);
      flash('Категория удалена.');
    } catch (error) {
      flash(error.reason || error.message, 'error');
    }
  }
});

Template.adminComments.onCreated(function () {
  subscribeAdmin(this, 'posts.admin', 'comments.admin');
});

Template.adminComments.helpers({
  adminCommentsList() {
    return Comments.find({}, { sort: { approved: 1, createdAt: -1 } });
  },
  commentPostTitle(postId) {
    return Posts.findOne(postId)?.title || 'Пост удалён';
  }
});

Template.adminComments.events({
  async 'click .js-comment-approve'(event) {
    try {
      await call('comments.setApproved', this._id, event.currentTarget.dataset.approved === 'true');
      flash('Комментарий обновлён.');
    } catch (error) {
      flash(error.reason || error.message, 'error');
    }
  },
  async 'click .js-comment-remove'() {
    if (!window.confirm('Удалить комментарий?')) return;
    try {
      await call('comments.remove', this._id);
      flash('Комментарий удалён.');
    } catch (error) {
      flash(error.reason || error.message, 'error');
    }
  }
});

Template.adminSettings.helpers({
  settings() {
    return Settings.findOne('main') || {};
  }
});

Template.adminSettings.events({
  async 'submit .js-settings-form'(event) {
    event.preventDefault();
    const form = event.currentTarget;

    try {
      await call('settings.update', {
        siteName: form.siteName.value,
        siteDescription: form.siteDescription.value,
        heroTitle: form.heroTitle.value,
        heroText: form.heroText.value,
        footerText: form.footerText.value
      });
      flash('Настройки сохранены.');
    } catch (error) {
      flash(error.reason || error.message, 'error');
    }
  }
});
